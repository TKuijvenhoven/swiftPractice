//import UIKit

let numberOfTickets = 150

let ticketPrice = 10

let roomRentalFee = 100

let posterCost = 40

// Caculation
let totalValue = numberOfTickets * ticketPrice

let totalExpenses = roomRentalFee + posterCost

let totalIncome = ticketPrice 
