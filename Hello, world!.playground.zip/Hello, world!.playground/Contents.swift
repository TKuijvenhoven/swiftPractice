import UIKit

//var greeting = "Hello, playground"
//print("Hello, world!")
//
//let name = "John"
//let pi = "3.14159"
//name = "Micheal"
//
//var age = 29
//age 30

let defaultScore = 100
var playerOneScore = defaultScore
var playerTwoScore = defaultScore
print (playerOneScore)
print (playerTwoScore)
playerOneScore = 200
print(playerOneScore)

